<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\EmployeeController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::view('/adminlogin','backend/admin_login');
Route::post('/admin_auth',[AdminController::class,'auth_process']);
Route::group(['middleware'=>'admin_auth'],function(){
Route:: view('dashboard','backend/admin_welcome');
Route::view('Add_New','backend/add_new_employee');
Route::post('admin/add/employee',[EmployeeController::class,'store']);
Route::get('Employee_list',[EmployeeController::class,'index']);
Route::post('admin/employee/status/{status}/{id}',[EmployeeController::class,'employee_status']);
Route::get('admin/employee_details/{id}',[EmployeeController::class,'employee_details']);
Route::post('admin/update/employee/{id}',[EmployeeController::class,'update_employee_details']);
Route::post('admin/employee/delete/{id}',[EmployeeController::class,'employee_data_delete']);
  Route::get('admin/logout', function () {
    if(Session::has('admin'))
    {
    session()->forget('admin');
    session()->flash('error','Logout sucessfully');
    }
    return redirect('/adminlogin');
});

});
