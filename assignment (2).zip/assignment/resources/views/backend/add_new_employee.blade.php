@extends('backend/admin_layout')
@section('page_title','Add New Employee')
@section('container')



               <div class="midde_cont">
                  <div class="container-fluid">
                     <div class="row column_title">
                        <div class="col-md-12">
                           <div class="page_title">
                              <h2>Add New Employee</h2>
                           </div>
                        </div>
                     </div>
                     <div class="container">
                      <div class="row m-t-30">
        <div class="col-md-12">
        <div class="row">
        <div class="col-lg-12">
        <!-- <center><h1 class="mb10">:-</h1></center><br> -->
        <div class="card">
        <div class="card-body">
        <form  action="{{url('admin/add/employee')}}"  method="POST">
         @csrf
        <div class="form-group">
        <div class="row">
        <div class="col-md-6">
        <label for="Employee_name" class="control-label mb-1"> Employee Name</label>
        <input  name="emp_name" type="text"  class="form-control" aria-required="true" aria-invalid="false" placeholder="Enter Employee Name" value="{{old('emp_name')}}">
        @if ($errors->has('emp_name'))
                    <span class="text-danger">{{ $errors->first('emp_name') }}</span>
                @endif<br>
        </div> 
        <div class="col-md-6">
        <label for="Employee_Dob" class="control-label mb-1"> Employee DOB</label>
        <input  name="emp_dob" type="date"  class="form-control" aria-required="true" aria-invalid="false" placeholder="Enter Page Name" value="{{old('emp_dob')}}">
        @if ($errors->has('emp_dob'))
                    <span class="text-danger">{{ $errors->first('emp_dob') }}</span>
                @endif<br>
        </div>   
        </div>
         <div class="row pt-3">
        <div class="col-md-6">
        <label for="Employee Salary" class="control-label mb-1"> Employee Salary</label>
        <input  name="emp_salary" type="text"  class="form-control" aria-required="true" aria-invalid="false" placeholder="Enter Employee Salary" value="{{old('emp_salary')}}">
        @if ($errors->has('emp_salary'))
                    <span class="text-danger">{{ $errors->first('emp_salary') }}</span>
                @endif<br>
        </div> 
        <div class="col-md-6">
        <label for="Employee Joining_Date" class="control-label mb-1">Joining Date</label>
        <input  name="emp_joining_date" type="date"  class="form-control" aria-required="true" aria-invalid="false" placeholder="Enter Joining Date" value="{{old('emp_joining_date')}}">
        @if ($errors->has('emp_joining_date'))
                    <span class="text-danger">{{ $errors->first('emp_joining_date') }}</span>
                @endif<br>
        </div>   
        </div>
         <div class="row pt-3">
        <div class="col-md-6">
        <label for="Employee_Relieving_Date" class="control-label mb-1">Relieving Date</label>
        <input  name="emp_relieving_date" type="date"  class="form-control" aria-required="true" aria-invalid="false" placeholder="Enter Page Name" value="{{old('emp_relieving_date')}}">
        </div> 
        <div class="col-md-6">
        <label for="Employee_Contact" class="control-label mb-1">Employee Contact No.</label>
        <input  name="emp_contact" type="text"  class="form-control" aria-required="true" aria-invalid="false" placeholder="Enter Contact Number" value="{{old('emp_contact')}}"> 
        @if ($errors->has('emp_contact'))
                    <span class="text-danger">{{ $errors->first('emp_contact') }}</span>
                @endif<br>
        </div>   
        </div>
        </div>
        <button  type="submit" class="btn btn-lg btn-info btn-block">Add New Employee</button>
        </div>
        </form>  
        
     </div>
     </div>
    </div>        
    </div>
                         
                        </div>
                   </div>
                   
                  


@endsection