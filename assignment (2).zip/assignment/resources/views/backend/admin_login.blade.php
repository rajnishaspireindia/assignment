<title>Admin Login</title>
<link rel="stylesheet" href="{{asset('admin/assets/css/external.css')}}">
<link rel="stylesheet" href="{{asset('admin/assets/css/bootstrap.min.css')}}" />
 

<!-- jQuery library -->
<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
@if(Session::has('admin'))
 <script>
   window.location='dashboard';
   </script>
@endif
    <body style="background:grey;">
    <div class="container">
<div id="login-form-wrap">
   <h4>Employee Management System</h4>
   <br>
  <form id="login-form" action="/admin_auth" method="POST">
      @csrf
    <p>
    <input type="text" id="username" name="email" placeholder="Username/Email Address"  style="border: 1px solid #c2c0ca;" required><i class="validation"><span></span><span></span></i>
    </p>
    <p>
    <input type="password" id="password" name="password" placeholder="Password" required><i class="validation"><span></span><span></span></i>
    </p>
    <p>
    <input type="submit" id="login" value="Login">
    </p>
    @if(session()->has('error'))
                                <div class="sufee-alert alert with-close alert-danger alert-dismissible fade show">
                                    {{session('error')}}  
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">×</span>
                                    </button>
                                </div> 
                                @endif 	
  </form>
  <div class="row">
      
<div class="col-md-6">
  <div id="create-account-wrap">
    
  </div> 
</div>
</div>
</div> 
</div>




