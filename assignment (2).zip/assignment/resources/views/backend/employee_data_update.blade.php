@extends('backend/admin_layout')
@section('page_title','Update Company Details')
@section('container')
  

<br><br>
<div class="full counter_section margin_bottom_30">
@if(session()->has('message'))
<style>
    .message 
    {
       margin:45px;
    }
     
</style>
<div class="message">
    <div class="sufee-alert alert with-close alert-success alert-dismissible fade show">
        {{session('message')}}  
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">×</span>
        </button>
    </div> 
</div>
    @endif     
 
@foreach($data as $list)
  
    <br><br>
    <div class="row m-t-30">
        <div class="col-md-12">
        <div class="row">
                <div class="col-lg-12">
                <center><h1 class="mb10">Manage Company Details:-</h1></center><br>
                    <div class="card">
                        <div class="card-body">
                            <form action="{{url('company/manage_process')}}/{{$list->id}}" method="post" enctype="multipart/form-data">
                                @csrf
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <label for="company_name" class="control-label mb-1">Company Name</label>
                                            <input id="company_name" value="{{$list->company_name}}" name="company_name" type="text" class="form-control" aria-required="true" aria-invalid="false">
                                        </div>

                                        <div class="col-md-4">
                                            <label for="sector" class="control-label mb-1">Sector</label>
                                            <input id="sector" value="{{$list->sector}}" name="sector" type="text" class="form-control" aria-required="true" aria-invalid="false">
                                        </div>

                                        <div class="col-md-4">
                                            <label for="ceo/md" class="control-label mb-1">Ceo Name</label>
                                            <input id="ceo" value="{{$list->ceo}}" name="ceo" type="text" class="form-control" aria-required="true" aria-invalid="false">
                                             
                                        </div>
                                    </div>
                                    
                                </div>
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <label for="membership" class="control-label mb-1">Membership</label>
                                            <input id="membership" value="{{$list->membership}}" name="membership" type="text" class="form-control" aria-required="true" aria-invalid="false">
                                        </div>

                                        <div class="col-md-4">
                                            <label for="cinnumber" class="control-label mb-1">Cin Number</label>
                                            <input id="cinnumber" value="{{$list->cinnumber}}" name="cinnumber" type="text" class="form-control" aria-required="true" aria-invalid="false">
                                        </div>

                                        <div class="col-md-4">
                                            <label for="contact_person" class="control-label mb-1">Contact Person</label>
                                            <input id="contact_person" value="{{$list->contact_person}}" name="contact_person" type="text" class="form-control" aria-required="true" aria-invalid="false">
                                             
                                        </div>
                                    </div>
                                    
                                </div>
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <label for="designation" class="control-label mb-1">Designation</label>
                                            <input id="designation" value="{{$list->designation}}" name="designation" type="text" class="form-control" aria-required="true" aria-invalid="false">
                                        </div>

                                        <div class="col-md-4">
                                            <label for="email" class="control-label mb-1">Email</label>
                                            <input id="mail_id" value="{{$list->mail_id}}" name="mail_id" type="email" class="form-control" aria-required="true" aria-invalid="false" >
                                        </div>

                                        <div class="col-md-4">
                                            <label for="phone" class="control-label mb-1">Phone Number</label>
                                            <input id="phone" value="{{$list->phone}}" name="phone" type="text" class="form-control" aria-required="true" aria-invalid="false">
                                             
                                        </div>
                                    </div>
                                    
                                </div>
                                <div class="form-group">
                                    <div class="row">
                                    <div class="col-md-4">
                                            <label for="address" class="control-label mb-1">Address</label>
                                            <textarea id="address"   name="address" type="text" class="form-control" aria-required="true" aria-invalid="false">{{$list->address}}</textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="logo" class="control-label mb-1"> Image</label>
                                    <input id="company_logo" name="logo" type="file" class="form-control" aria-required="true"  aria-invalid="false">
                                   
                                    @if($list->logo!='')
                                            <a href="" target="_blank"><img width="100px" src="{{asset('company_logo/'.$list->logo)}}"/></a>
                                        @endif
                                </div>
                                <div>
                                    <button id="payment-button" type="submit" class="btn btn-lg btn-info btn-block">
                                        Update
                                    </button>
                                </div>
                                <input type="hidden" name="id" value="{{$list->id}}"/>
                            </form>
                        </div>
                    </div>
                </div>
            </div>        
        </div>
    </div>



</div>
@endforeach









@endsection