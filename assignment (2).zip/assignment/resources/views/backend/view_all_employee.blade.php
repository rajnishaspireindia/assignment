@extends('backend/admin_layout')
@section('page_title','Employee List')
@section('container')
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.2.0/sweetalert2.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.2.0/sweetalert2.all.min.js"></script>
<?php 
                          if(isset($_GET['success']))
                          {
                          echo '<script>swal("<h4>New Employee Data added successfully!</h4>", "", "success");</script>' ;
                          }
                            if(isset($_GET['status']))
                            {
                            echo '<script>swal("<h4>Employee Status  Updated successfully!</h4>", "", "success");</script>' ;
                            } 
                            if(isset($_GET['update']))
                            {
                            echo '<script>swal("<h4>Employee details   Updated successfully!</h4>", "", "success");</script>' ;
                            } 
                            if(isset($_GET['delete']))
                            {
                            echo '<script>swal("<h4>Employee details   deleted successfully!</h4>", "", "success");</script>' ;
                            } 
                        ?>   
<div class="full counter_section margin_bottom_30">
<div class="container">  
    <div class="row m-t-30">
     <div class="col-md-12"> 
	<div class="row" id="search">
	<div class="form-group col-lg-12">
	<input class="form-control" country="text" id="myInput" placeholder="Search Employee..." />
	</div>	 
	</div>
            <!-- DATA TABLE-->
            <div class="table-responsive m-b-40">
                <table class="table table-borderless table-data3">
                    <thead>
                        <tr>
                            <th><b>ID</b></th>
                            <th><b>Employee Name</b></th>
                            <th><b>Employee DOB</b></th>
                            <th><b>Employee Salary</b></th>
                            <th><b>Employee Joining Date</b></th>
                            <th><b>Status</b></th>
                            <th><b>Action</b></th>
                        </tr>
                    </thead>
                    <tbody id="myTable">
                        @foreach($data as $list)
                        <tr>
                            <td>{{$list->id}}</td>
                            <td>{{$list->emp_name}}</td>
                            <td>{{$list->emp_dob}}</td>
                            <td>{{$list->emp_salary}}</td>
                            <td>{{$list->emp_joining_date}}</td>
                            <td> @if($list->status==1)
                                <form method="POST" action="{{url('admin/employee/status/0')}}/{{$list->id}}">
                                    @csrf
                                    <input name="_method" type="hidden">
                                    <button type="submit" class="btn btn-xs btn-primary btn-flat show_confirm_deactive" data-toggle="tooltip" title='Active'><i class='fa fa-rocket'aria-hidden='true'></i> Active</button>
                                 </form>
                                 @elseif($list->status==0)
                                 <form method="POST" action="{{url('admin/employee/status/1')}}/{{$list->id}}">
                                 @csrf
                                    <input name="_method" type="hidden">
                                    <button type="submit" class="btn btn-xs btn-danger btn-flat show_confirm_active" data-toggle="tooltip" title='Active'><i class='fa fa-eye-slash'aria-hidden='true'></i> Deactive</button>
                                 </form>
                                @endif
                            </td>
                            <td>
                            <a href="{{url('admin/employee_details')}}/{{($list->id)}}"><button type="button" class="btn btn-success"> <i class="fa fa-edit"></i> View</button></a>
                                <!-- <a href="{{url('admin/employee_details_delete')}}/{{($list->id)}}"><button type="button" class="btn btn-danger"> <i class="fa fa-trash"></i> Delete</button></a> -->
                                 <form method="POST" action="{{url('admin/employee/delete')}}/{{($list->id)}}">
                            @csrf
                            <input name="_method" type="hidden">
                            <button type="submit" class="btn btn-xs btn-danger btn-flat show_confirm" data-toggle="tooltip" title='Delete'><i class="fa fa-remove"></i> Delete</button>
                        </form>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
            {{ $data->links('pagination::bootstrap-4') }}
            <!-- END DATA TABLE-->
        </div>
    </div>
</div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script>
$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.2.0/sweetalert2.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.0/sweetalert.min.js"></script>
   <script type="text/javascript">
     $('.show_confirm').click(function(event) {
          var form =  $(this).closest("form");
          var name = $(this).data("name");
          event.preventDefault();
          swal({
              title:"Are you sure you want to delete this Employee?",
              text: "If you delete this, it will be gone forever.",
              icon: "warning",
              buttons: true,
              dangerMode: true,
          })
          .then((willDelete) => {
            if (willDelete) {
              form.submit();
            }
          });
      });
      $('.show_confirm_deactive').click(function(event) {
          var form =  $(this).closest("form");
          var name = $(this).data("name");
          event.preventDefault();
          swal({
              title:"Are you sure you want to deactive  this Employee?",
              text: "If you deactive this, it will be disabled.",
              icon: "warning",
              buttons: true,
              dangerMode: true,
          })
          .then((willDelete) => {
            if (willDelete) {
              form.submit();
            }
          });
      });
      $('.show_confirm_active').click(function(event) {
          var form =  $(this).closest("form");
          var name = $(this).data("name");
          event.preventDefault();
          swal({
              title:"Are you sure you want to active  this Employee?",
              text: "If you active this, it will be  show on home page.",
              icon: "warning",
              buttons: true,
              dangerMode: true,
          })
          .then((willDelete) => {
            if (willDelete) {
              form.submit();
            }
          });
      });
</script>
@endsection