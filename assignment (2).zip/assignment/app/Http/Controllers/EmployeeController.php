<?php

namespace App\Http\Controllers;

use App\Models\Employee;
use Illuminate\Http\Request;

class EmployeeController extends Controller
{
    
    public function index()
    {
        $result['data']=Employee::paginate(10);
        return view('backend/view_all_employee',$result);
    }

    public function store(Request $request)
    {
     $request->validate([
            'emp_name'=>'required',
            'emp_dob'=>'required',
            'emp_salary'=>'required|numeric',
            'emp_joining_date'=>'required',
            'emp_contact'=>'required|numeric|'

     ]);
     $data=new Employee();
     $data->emp_name=$request->post('emp_name');
     $data->emp_dob=$request->post('emp_dob');
     $data->emp_salary=$request->post('emp_salary');
     $data->emp_joining_date=$request->post('emp_joining_date');
     $data->emp_relieving_date=$request->post('emp_relieving_date');
     $data->emp_contact=$request->post('emp_contact');
     $data->save();
       return redirect('Employee_list?success');

    }

    
    public function employee_details(Request $request,$id)
    {
        $details['data']=Employee::where(['id'=>$id])->get();
        return view('backend/employee_detail',$details);
    }
    public function employee_status(Request $request,$status,$id)
   {
    
    $model=Employee::find($id);
    $model->status=$status;
    $model->save();
    return redirect('Employee_list?status');
   }
    
    public function update_employee_details(Request $request ,$id)
    {
        $employee_detail=Employee::find($id);
        $employee_detail->emp_name=$request->post('emp_name');
        $employee_detail->emp_dob=$request->post('emp_dob');
        $employee_detail->emp_salary=$request->post('emp_salary');
        $employee_detail->emp_joining_date=$request->post('emp_joining_date');
        $employee_detail->emp_relieving_date=$request->post('emp_relieving_date');
        $employee_detail->emp_contact=$request->post('emp_contact');
        $employee_detail->update();
         return redirect('Employee_list?update');

    }


    public function employee_data_delete(Request $request,$id)
    {
        $result=Employee::find($id);
        $result->delete();
         return redirect('Employee_list?delete');

    }
}
