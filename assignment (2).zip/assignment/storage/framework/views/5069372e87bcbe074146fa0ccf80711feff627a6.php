
<?php $__env->startSection('page_title','Employee List'); ?>
<?php $__env->startSection('container'); ?>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.2.0/sweetalert2.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.2.0/sweetalert2.all.min.js"></script>
<?php 
                          if(isset($_GET['success']))
                          {
                          echo '<script>swal("<h4>New Employee Data added successfully!</h4>", "", "success");</script>' ;
                          }
                            if(isset($_GET['status']))
                            {
                            echo '<script>swal("<h4>Employee Status  Updated successfully!</h4>", "", "success");</script>' ;
                            } 
                            if(isset($_GET['update']))
                            {
                            echo '<script>swal("<h4>Employee details   Updated successfully!</h4>", "", "success");</script>' ;
                            } 
                            if(isset($_GET['delete']))
                            {
                            echo '<script>swal("<h4>Employee details   deleted successfully!</h4>", "", "success");</script>' ;
                            } 
                        ?>   
<div class="full counter_section margin_bottom_30">
<div class="container">  
    <div class="row m-t-30">
     <div class="col-md-12"> 
	<div class="row" id="search">
	<div class="form-group col-lg-12">
	<input class="form-control" country="text" id="myInput" placeholder="Search Employee..." />
	</div>	 
	</div>
            <!-- DATA TABLE-->
            <div class="table-responsive m-b-40">
                <table class="table table-borderless table-data3">
                    <thead>
                        <tr>
                            <th><b>ID</b></th>
                            <th><b>Employee Name</b></th>
                            <th><b>Employee DOB</b></th>
                            <th><b>Employee Salary</b></th>
                            <th><b>Employee Joining Date</b></th>
                            <th><b>Status</b></th>
                            <th><b>Action</b></th>
                        </tr>
                    </thead>
                    <tbody id="myTable">
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($list->id); ?></td>
                            <td><?php echo e($list->emp_name); ?></td>
                            <td><?php echo e($list->emp_dob); ?></td>
                            <td><?php echo e($list->emp_salary); ?></td>
                            <td><?php echo e($list->emp_joining_date); ?></td>
                            <td> <?php if($list->status==1): ?>
                                <form method="POST" action="<?php echo e(url('admin/employee/status/0')); ?>/<?php echo e($list->id); ?>">
                                    <?php echo csrf_field(); ?>
                                    <input name="_method" type="hidden">
                                    <button type="submit" class="btn btn-xs btn-primary btn-flat show_confirm_deactive" data-toggle="tooltip" title='Active'><i class='fa fa-rocket'aria-hidden='true'></i> Active</button>
                                 </form>
                                 <?php elseif($list->status==0): ?>
                                 <form method="POST" action="<?php echo e(url('admin/employee/status/1')); ?>/<?php echo e($list->id); ?>">
                                 <?php echo csrf_field(); ?>
                                    <input name="_method" type="hidden">
                                    <button type="submit" class="btn btn-xs btn-danger btn-flat show_confirm_active" data-toggle="tooltip" title='Active'><i class='fa fa-eye-slash'aria-hidden='true'></i> Deactive</button>
                                 </form>
                                <?php endif; ?>
                            </td>
                            <td>
                            <a href="<?php echo e(url('admin/employee_details')); ?>/<?php echo e(($list->id)); ?>"><button type="button" class="btn btn-success"> <i class="fa fa-edit"></i> View</button></a>
                                <!-- <a href="<?php echo e(url('admin/employee_details_delete')); ?>/<?php echo e(($list->id)); ?>"><button type="button" class="btn btn-danger"> <i class="fa fa-trash"></i> Delete</button></a> -->
                                 <form method="POST" action="<?php echo e(url('admin/employee/delete')); ?>/<?php echo e(($list->id)); ?>">
                            <?php echo csrf_field(); ?>
                            <input name="_method" type="hidden">
                            <button type="submit" class="btn btn-xs btn-danger btn-flat show_confirm" data-toggle="tooltip" title='Delete'><i class="fa fa-remove"></i> Delete</button>
                        </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <?php echo e($data->links('pagination::bootstrap-4')); ?>

            <!-- END DATA TABLE-->
        </div>
    </div>
</div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script>
$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.2.0/sweetalert2.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.0/sweetalert.min.js"></script>
   <script type="text/javascript">
     $('.show_confirm').click(function(event) {
          var form =  $(this).closest("form");
          var name = $(this).data("name");
          event.preventDefault();
          swal({
              title:"Are you sure you want to delete this Employee?",
              text: "If you delete this, it will be gone forever.",
              icon: "warning",
              buttons: true,
              dangerMode: true,
          })
          .then((willDelete) => {
            if (willDelete) {
              form.submit();
            }
          });
      });
      $('.show_confirm_deactive').click(function(event) {
          var form =  $(this).closest("form");
          var name = $(this).data("name");
          event.preventDefault();
          swal({
              title:"Are you sure you want to deactive  this Employee?",
              text: "If you deactive this, it will be disabled.",
              icon: "warning",
              buttons: true,
              dangerMode: true,
          })
          .then((willDelete) => {
            if (willDelete) {
              form.submit();
            }
          });
      });
      $('.show_confirm_active').click(function(event) {
          var form =  $(this).closest("form");
          var name = $(this).data("name");
          event.preventDefault();
          swal({
              title:"Are you sure you want to active  this Employee?",
              text: "If you active this, it will be  show on home page.",
              icon: "warning",
              buttons: true,
              dangerMode: true,
          })
          .then((willDelete) => {
            if (willDelete) {
              form.submit();
            }
          });
      });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend/admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp1\htdocs\assignment\resources\views/backend/view_all_employee.blade.php ENDPATH**/ ?>