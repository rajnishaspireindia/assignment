
<?php $__env->startSection('page_title','Welcome Page'); ?>
<?php $__env->startSection('container'); ?>
<?php 
use App\Models\Employee;
$data=Employee::count();
?>

               <div class="midde_cont">
                  <div class="container-fluid">
                     <div class="row column_title">
                        <div class="col-md-12">
                           <div class="page_title">
                              <h2>Dashboard</h2>
                           </div>
                        </div>
                     </div>
                     <div class="container">
                     <div class="row column1">
                        <div class="col-md-6 col-lg-4">
                        <a href="<?php echo e(url('Employee_list')); ?>"> 
                           <div class="full counter_section margin_bottom_30">
                              <div class="couter_icon">
                                 <div> 
                                    <i class="fa fa-user yellow_color"></i>
                                 </div>
                                 <p class="total_no" style="font-size:80px;"><?php echo e($data); ?></p>
                              </div>
                            
                              <div class="counter_no">
                                 <div>
                                    
                                   <p class="head_couter" style="text-align:center;">Total Employees</p>
                                 </div>
                              </div>
                              </a>
                           </div>
                        </div>
                        
                        </div>
                         
                        </div>
                   </div>
                   

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend/admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp1\htdocs\assignment\resources\views/backend/admin_welcome.blade.php ENDPATH**/ ?>