<!DOCTYPE html>
<html lang="en">
   <head>
      <!-- basic -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <!-- mobile metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="viewport" content="initial-scale=1, maximum-scale=1">
     
      <title><?php echo $__env->yieldContent('page_title'); ?></title>
      <meta name="keywords" content="">
      <meta name="description" content="">
      <meta name="author" content="">
      <!-- site icon -->
      <link rel="icon" href="<?php echo e(asset('admin/images/logo/adminlogo.png')); ?>" type="image/png" />
      <!-- bootstrap css -->
      <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/bootstrap.min.css')); ?>" />
      <!-- site css -->
      <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/style.css')); ?>" />
      <!-- responsive css -->
      <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/responsive.css')); ?>" />
      <!-- color css -->
      <!-- <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/colors.css')); ?>" /> -->
      <!-- select bootstrap -->
      <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/bootstrap-select.css')); ?>" />
      <!-- scrollbar css -->
      <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/perfect-scrollbar.css')); ?>" />
      <!-- custom css -->
      <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/custom.css')); ?>"/>
   </head>
   <body class="dashboard dashboard_1">
      <div class="full_container">
         <div class="inner_container">
            <?php if(Session::has('admin')): ?>
            <!-- Sidebar  -->
            <nav id="sidebar">
               <div class="sidebar_blog_2">
                  <h4>Welcome Admin</h4>
                  <ul class="list-unstyled components">
                     <li>
                        <a href="<?php echo e(url('dashboard')); ?>"><i class="fa fa-dashboard yellow_color"></i> <span>Dashboard</span></a>
                     </li>  
                     <li>
                        <a href="#manage" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-object-group blue2_color"></i> <span>Employee Management</span></a>
                        <ul class="collapse list-unstyled" id="manage">
                           <li><a href="<?php echo e(url('Add_New')); ?>">> <span>Add New Employee</span></a></li>
                           <li><a href="<?php echo e(url('Employee_list')); ?>">> <span>View All Employee</span></a></li>
                            
                        </ul>
                     </li>
                  </ul>

               </div>
            </nav>
            <!-- end sidebar -->
            <!-- right content -->
            <div id="content">
               <!-- topbar -->
               <div class="topbar">
                  <nav class="navbar navbar-expand-lg navbar-light">
                     <div class="full">
                        <button type="button" id="sidebarCollapse" class="sidebar_toggle"><i class="fa fa-bars"></i></button>
                        <div class="logo_section">
                        </div>
                        <div class="right_topbar">
                           <div class="icon_info">
         
                              <ul class="user_profile_dd">
                                 <li>
                                    <a class="dropdown-toggle" data-toggle="dropdown"><img class="img-responsive rounded-circle" src="<?php echo e(asset('admin/images/logo')); ?>/<?php echo e(Session::get('admin')['admin_logo']); ?>" alt="#" /><span class="name_user">Welcome <?php echo e(Session::get('admin')['username']); ?></span></a>
                                    <div class="dropdown-menu">
                                       <a class="dropdown-item" href="<?php echo e(url('admin/logout')); ?>"><span>Log Out</span> <i class="fa fa-sign-out"></i></a>
                                    </div>
                                 </li>
                              </ul>
                           </div>
                        </div>
                     </div>
                  </nav>
               </div>
               
            <!-- end sidebar -->
               <?php endif; ?>
               <!-- end topbar -->
               <!-- dashboard inner --> 
           <?php $__env->startSection('container'); ?>
           <?php echo $__env->yieldSection(); ?>
          <!-- footer -->
                  <div class="container">
                     <div class="footer">
                     <p>  Employee Management System &copy; 2022 <a>All rights reserved.</a></p>        
                        
                     </div>
                  </div>
               </div>
               <!-- end dashboard inner -->
            </div>
         </div>
      </div>
      <!-- jQuery -->
      <script src="<?php echo e(asset('admin/assets/js/jquery.min.js')); ?>"></script>
      <script src="<?php echo e(asset('admin/assets/js/popper.min.js')); ?>"></script>
      <script src="<?php echo e(asset('admin/assets/js/bootstrap.min.js')); ?>"></script>
      <!-- wow animation -->
      <script src="<?php echo e(asset('admin/assets/js/animate.js')); ?>"></script>
      <!-- select country -->
      <script src="<?php echo e(asset('admin/assets/js/bootstrap-select.js')); ?>"></script>
      <!-- owl carousel -->
      <script src="<?php echo e(asset('admin/assets/js/owl.carousel.js')); ?>"></script> 
      <!-- chart js -->
       
      <script src="<?php echo e(asset('admin/assets/js/utils.js')); ?>"></script>
       
      <!-- nice scrollbar -->
      <script src="<?php echo e(asset('admin/assets/js/perfect-scrollbar.min.js')); ?>"></script>
      <script>
         var ps = new PerfectScrollbar('#sidebar');
      </script>
      <!-- custom js -->
      <script src="<?php echo e(asset('admin/assets/js/custom.js')); ?>"></script>
      
   </body>
</html><?php /**PATH C:\xampp1\htdocs\assignment\resources\views/backend/admin_layout.blade.php ENDPATH**/ ?>