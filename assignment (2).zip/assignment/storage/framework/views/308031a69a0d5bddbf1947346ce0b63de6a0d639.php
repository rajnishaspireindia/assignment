
<?php $__env->startSection('page_title','Employee Details'); ?>
<?php $__env->startSection('container'); ?>

               <div class="midde_cont">
                  <div class="container-fluid">
                     <div class="row column_title">
                        <div class="col-md-12">
                           <div class="page_title">
                              <h2> Employee Details:-</h2>
                           </div>
                        </div>
                     </div>
                     <div class="container">
                      <div class="row m-t-30">
        <div class="col-md-12">
        <div class="row">
        <div class="col-lg-12">
        <!-- <center><h1 class="mb10">:-</h1></center><br> -->
        <div class="card">
        <div class="card-body">
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <form  action="<?php echo e(url('admin/update/employee')); ?>/<?php echo e($list->id); ?>"  method="POST">
         <?php echo csrf_field(); ?>
        <div class="form-group">
        <div class="row">
        <div class="col-md-6">
        <label for="Employee_name" class="control-label mb-1"> Employee Name</label>
        <input  name="emp_name" type="text"  class="form-control" aria-required="true" aria-invalid="false" placeholder="Enter Employee Name" value="<?php echo e($list->emp_name); ?>">

        </div> 
        <div class="col-md-6">
        <label for="Employee_Dob" class="control-label mb-1"> Employee DOB</label>
        <input  name="emp_dob" type="date"  class="form-control" aria-required="true" aria-invalid="false" placeholder="Enter Page Name" value="<?php echo e($list->emp_dob); ?>">

        </div>   
        </div>
         <div class="row pt-3">
        <div class="col-md-6">
        <label for="Employee Salary" class="control-label mb-1"> Employee Salary</label>
        <input  name="emp_salary" type="text"  class="form-control" aria-required="true" aria-invalid="false" placeholder="Enter Employee Salary" value="<?php echo e($list->emp_salary); ?>">

        </div> 
        <div class="col-md-6">
        <label for="Employee Joining_Date" class="control-label mb-1">Joining Date</label>
        <input  name="emp_joining_date" type="date"  class="form-control" aria-required="true" aria-invalid="false" placeholder="Enter Joining Date" value="<?php echo e($list->emp_joining_date); ?>">

        </div>   
        </div>
         <div class="row pt-3">
        <div class="col-md-6">
        <label for="Employee_Relieving_Date" class="control-label mb-1">Relieving Date</label>
        <input  name="emp_relieving_date" type="date"  class="form-control" aria-required="true" aria-invalid="false" placeholder="Enter Page Name" value="<?php echo e($list->emp_relieving_date); ?>">
        </div> 
        <div class="col-md-6">
        <label for="Employee_Contact" class="control-label mb-1">Employee Contact No.</label>
        <input  name="emp_contact" type="text"  class="form-control" aria-required="true" aria-invalid="false" placeholder="Enter Contact Number" value="<?php echo e($list->emp_contact); ?>"> 
        
        </div>   
        </div>
        </div>
        <button  type="submit" class="btn btn-lg btn-info btn-block">Update Employee Details</button>
        </div>
        </form>  
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </div>
     </div>
    </div>        
    </div>
                         
                        </div>
                   </div>
                   
                  

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend/admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp1\htdocs\assignment\resources\views/backend/employee_detail.blade.php ENDPATH**/ ?>